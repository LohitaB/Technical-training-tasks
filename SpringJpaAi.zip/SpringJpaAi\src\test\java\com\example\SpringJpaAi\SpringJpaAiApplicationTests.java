package com.example.SpringJpaAi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
