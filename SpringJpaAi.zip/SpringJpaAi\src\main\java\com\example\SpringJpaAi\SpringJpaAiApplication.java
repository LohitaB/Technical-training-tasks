package com.example.SpringJpaAi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaAiApplication.class, args);
	}

}
